import pickle
import streamlit as st
from tmdbv3api import Movie, TMDb

# 객체를 만들어서 초기화
movie = Movie()
tmdb = TMDb()

tmdb.api_key = '95c17982816fb547355f10402c0257a6'   # 서버와 데이터를 연결
tmdb.language = 'ko-KR'     # 기본언어를 한글로

def get_recommendations(title):
    # 영화 제목을 통해서 전체 데이터 기준 그 영화의 index 값을 얻기
    idx = movies[movies['title'] == title].index[0]

    # 코사인 유사도 매트릭스 (cosine_sim) 에서 idx 에 해당하는 데이터를 (idx, 유사도) 형태로 얻기
    sim_scores = list(enumerate(cosine_sim[idx]))

    # 코사인 유사도 기준으로 내림차순 정렬
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    
    # 자기 자신을 제외한 10개의 추천 영화를 슬라이싱
    sim_scores = sim_scores[1:11]
    
    # 추천 영화 목록 10개의 인덱스 정보 추출
    movie_indices = [i[0] for i in sim_scores]
    
    # 인덱스 정보를 통해 영화 제목 추출
    images = []
    titles = []
    for i in movie_indices:
        id = movies['id'].iloc[i]
        details = movie.details(id)

        # 예외 처리
        image_path = details['poster_path']
        if image_path:
            image_path = 'https://image.tmdb.org/t/p/w500' + image_path
        else:
            image_path = 'no_image.jpg'

        images.append(image_path)
        titles.append(details['title'])

    return images, titles

# 데이터 불러오기
movies = pickle.load(open('movies.pickle', 'rb')) # 파일 읽기
cosine_sim = pickle.load(open('cosine_sim.pickle', 'rb'))

st.set_page_config(layout='wide')
st.header('OSJ_Movieworld')

movie_list = movies['title'].values
title = st.selectbox('Choose a movie you like', movie_list)     # 영화 리스트를 선택하면 그 영화 데이터가 선택됨
if st.button('Recommend'):      # 추천 버튼 만들기
    with st.spinner('Please wait...'):      # 로딩 중 화면
        images, titles = get_recommendations(title)

        idx = 0
        for i in range(0, 2):
            cols = st.columns(5)
            for col in cols:
                col.image(images[idx])
                col.write(titles[idx])
                idx += 1